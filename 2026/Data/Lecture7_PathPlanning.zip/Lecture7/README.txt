Lecture 7: Path Planning for Autonomous Driving

Extract this archive, then open Labs/PathPlanning/index.html.
The nine experiments run offline with no installation.
The editable PPTX and static PDF are in Presentations/.
PPTX demo links use relative paths within this package.
The README in the demo folder contains suggested experiments and model assumptions.
