# Lecture 8: Control for autonomous driving

Open `index.html` in a modern browser. All six demonstrations run offline, with no installation or external libraries. In the complete lecture ZIP, open `START_HERE.html` after extraction. The lecture is designed for about 65–80 minutes, with instructor-led demonstrations and verbal discussion. No by-hand calculations, worksheets, or submitted results are required.

## Demonstrations

| View | Implemented controller | What to watch |
| --- | --- | --- |
| PID speed | P, I, filtered derivative on measurement, optional nominal drag feedforward, conditional anti-windup | Reject a hill load, then brake with/without anti-windup |
| Pure Pursuit | Rear-axle target geometry using actual target chord distance | Change lookahead and speed |
| Stanley | Front-axle cross-track and heading feedback, low-speed softening | Change gain and command delay |
| LQR | Discrete Riccati iteration, speed-dependent gain, curvature feedforward | Trade state error against steering effort |
| MPC | Finite-horizon linear error model, quadratic cost, angle/rate constrained QP | Change preview horizon, limits, and model mismatch |
| Compare | Four independent lateral closed loops with shared conditions | Compare measured behavior under a controlled scenario |

## Start with a guided case

Choose a case from the dropdown, press **Play** to watch the motion, then choose a contrasting case. Use **Step** to inspect one decision or **Run 20 s** to jump to a completed response. Guided cases set every parameter. Manual changes create a custom run. The P and PI hill presets both set Kd = 0, so the controller names match their implemented terms.

Changing settings, loading a new case, or resetting automatically saves a nonempty current run. Up to four saved runs stay in the comparison table, and the most recent compatible run is dashed on the plots. Runs with a different path or speed-target profile remain in the table but are not overlaid against the current reference. Each algorithm keeps its own settings, run progress and saved comparisons when switching tabs. These runs live only in the current page session; export before reloading or closing.

**Close-up** shows the vehicle, applied steering, reference, target/error geometry and current MPC prediction with equal axis scales. **Full route** enlarges the lateral axis to show small tracking differences. Use the close-up for interpreting angles. The explanatory decision text comes from the same calculation used to control the simulation, without advancing it. The input plot separates requested, bounded and applied commands. Requests are drawn as held values from their issue time; applied steering is sampled at the end of each step. The Pure Pursuit orange arc shows the ideal requested turn before limits and lag, while the wheels show applied steering. Stanley also shows the path tangent at its front-axle reference. LQR’s optional contribution bars separate position feedback, heading feedback and bend feedforward. MPC’s optional sequence plot distinguishes commands sent from predicted wheel response.

**Full run** includes initial recovery in the error metrics. **After 2 s** excludes it. Every table row uses the same selected window, and the duration column exposes incomplete runs. Compare equal-duration runs. An empty selected interval shows a dash instead of a misleading zero.

**Export CSV** saves the current run, including PID term contributions and separate command-issue and state-sample times. The first line is `# settings=` metadata; skip it when parsing the table. **Export comparisons** saves the retained configurations and samples as JSON. These optional exports and numerical comparisons are inside a collapsed section. The [concept guide](concept-guide.html) explains each controller in words and suggests contrasting cases to replay.

## Teaching sequence

The 35-slide deck emphasizes concepts, visual behavior, and instructor demonstrations. There are no displayed equations, by-hand calculations, result tables to fill, or required exports.

1. **Feedback:** observe, correct, observe again. Contrast reaction with anticipation.
2. **PID:** watch the persistent speed gap on a hill, then the stored-correction problem during braking.
3. **Pure Pursuit and Stanley:** watch a target point versus heading/sideways correction. Compare gentle and strong responses, then add delay.
4. **LQR:** see how tracking priority and steering penalty change the feedback behavior. Contrast a preference with a physical limit.
5. **MPC:** follow the green prediction and the orange first action. Compare preview lengths, limits, and delayed actuation.
6. **Controller choice:** watch tracking, recovery, repeated swings, and steering activity under shared conditions.

The main demo explains decisions in ordinary language. Fine tuning, numerical comparisons, exports, and solver diagnostics are optional disclosures. The concept guide contains reading prompts rather than worksheet fields.

## Model and algorithm details

Coordinates use forward x, left y, and positive counterclockwise heading/steering. The vehicle position is the rear axle. Lateral errors are signed normal distances to a numerically located nearest point on the analytic reference. The initial `offset` is a world-y displacement, which differs slightly from a normal-distance offset on a sloped path.

The lateral plant is a nonlinear kinematic bicycle, wheelbase 2.7 m, fixed chosen speed, Euler step 0.05 s. Every method uses the same steering angle/rate bounds, first-order actuator lag and optional command delay/steering bias. There are no road boundaries, obstacles, tire slip, localization noise, or collision avoidance. The full-route view enlarges the lateral axis to reveal tracking differences; the close-up uses equal axis scales.

Pure Pursuit selects a forward reference point at least the chosen lookahead distance away, in 0.1 m search increments. It uses the actual chord distance in `delta = atan(2 L y_target / distance^2)`. Stanley uses `delta = path_heading - heading + atan(-gain * e_front / (speed + 0.5))`. Heading differences are wrapped. The common error plot and metrics always use the rear axle, even for Stanley.

LQR uses `A = [[1,v*dt],[0,1]]`, `B = [0,v*dt/L]^T`, `Q = diag(q,2)`, and `R = r`. A discrete Riccati iteration computes the gain when settings change. Curvature feedforward `atan(L*kappa)` accompanies feedback. The design omits actuator dynamics and input constraints. Clipping can invalidate the nominal linear behavior.

MPC optimizes N absolute steering inputs. Its linear error predictor includes the upcoming path curvature. The cost sums lateral error, heading error, and steering effort; the Tracking priority and Avoid large steering commands sliders adjust those preferences. There is no terminal penalty/set. The predictor includes configured first-order steering lag and the queued command delay. Angle bounds apply to requested commands; rate bounds apply to predicted applied steering, starting from the current steering state. A feasible active-set solver checks stationarity and multiplier signs as well as constraint feasibility, with a 400-iteration cap. Unconverged results are identified in the interface. The displayed first action is the command sent now, not a promise that the wheels immediately reach that angle. The predictor still omits steering bias and nonlinear tire behavior. This formulation does not impose road-edge or obstacle constraints and does not establish closed-loop stability.

The speed plant uses `dv/dt = actual_acceleration - 0.08*v - grade`. Acceleration limits are −4 to 2.5 m/s². The hill begins at 6 s. The braking reference changes to 4 m/s at 9 s. Derivative acts on speed and uses a 0.15 s low-pass filter. Anti-windup conditionally freezes the integral when saturation and error point in the same direction. Optional feedforward compensates nominal drag only.

## Metrics and interpretation

RMS/peak error use the selected Full run or After 2 s window. Command RMS is the limited steering request in degrees in the comparison table and radians in the CSV. It is not energy or a complete comfort metric. Actuator limiting counts command requests outside the angle/rate envelope; MPC can sit exactly at a legal bound without being counted as clipped. PID limiting counts acceleration saturation. Final error is signed.

This is a deterministic teaching comparison with illustrative tuning, not a production benchmark or an equal-tuning-effort ranking. Compare identical scenarios and report every setting. A lower RMS alone does not establish safety, robustness, or actuator feasibility.

## Sources

- [Coulter (1992), Implementation of the Pure Pursuit Path Tracking Algorithm](https://www.ri.cmu.edu/pub_files/pub3/coulter_r_craig_1992_1/coulter_r_craig_1992_1.pdf)
- [Thrun et al. (2006), Stanley: The Robot That Won the DARPA Grand Challenge](https://robots.stanford.edu/papers/thrun.stanley05.pdf). The lab implements the core geometric law, not the full vehicle controller.
- [MIT Underactuated Robotics, Linear Quadratic Regulators](https://underactuated.mit.edu/lqr.html)
- [do-mpc, Basics of Model Predictive Control](https://www.do-mpc.com/en/latest/theory_mpc.html)
- [MathWorks, Anti-Windup Control Using PID Controller Block](https://www.mathworks.com/help/simulink/slref/anti-windup-control-using-a-pid-controller.html)

Authoring and verification: `tools/slides/lecture8/`. The demo and offline package are versioned in GitHub; Pages publication uses the course workflow.

## Algorithm audit regression

Run `node tools/slides/lecture8/review-check.cjs` for numerical, plotting, and component checks. Run `python tools/slides/lecture8/check-control-reference.py` in an environment with NumPy and SciPy for independent constrained-MPC rollout/SLSQP comparisons and discrete-LQR Riccati checks. These are not live-browser tests.

The October 2026 correction replaced a fixed-iteration ADMM result followed by clipping, and included actuator lag/delay in MPC prediction. The earlier tight-limit and delay examples mixed optimizer error with actuator-model mismatch. They should not be used to teach that MPC inherently performs worse than the other methods. Aggressive Pure Pursuit, Stanley, and LQR settings can still lose tracking; the interface identifies large-error cases.

Reproduced 20-second MPC examples (rear-axle RMS error; illustrative simulation, not a benchmark):

| Case | Before correction | After correction |
| --- | ---: | ---: |
| Long horizon + tight limits | 9.54 m | 0.33 m |
| Long horizon + known delay | 23.05 m | 0.34 m |
| Comparison: faster vehicle | 7.38 m | 0.25 m |

Independent verification covered 72 constrained MPC states and 36 LQR configurations. The largest MPC objective difference from SciPy SLSQP was below 2e-8 in those cases. All nine published MPC teaching/comparison runs remained below 0.6 m RMS over 20 seconds. This finite regression coverage does not establish correctness for every arbitrary custom setting.

### Steering bias and teaching controls

With optional steering bias, the drawn front wheels and applied-input curve show the effective physical steering used by the vehicle model, including that bias. The internal actuator state and MPC predicted response omit the unknown bias. CSV exports include both `actuator` and `effective_steering_rad` so the distinction is explicit. PID remains a speed/acceleration demonstration.

The guided first action plays or pauses the motion so students can watch repeated decisions. `Run 20 s` remains available to inspect a completed run. Start with a named case, observe its response, and then change one condition. Damping, stronger gains, or longer preview do not guarantee better overall tracking under every tuning and physical constraint.
