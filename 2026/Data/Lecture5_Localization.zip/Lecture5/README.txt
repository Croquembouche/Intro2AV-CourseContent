Lecture 5: Localization

Open Labs/Localization/index.html to use the demos offline.
Open Presentations/Lecture 5 Localization for Autonomous Driving.pptx for the slides.
The teaching guide contains pacing, discussion prompts, and explanations.
GIF animations are embedded in the PPTX and available in Labs/Localization/gifs/.
Slides link to the online demos; use the local index.html when offline.
