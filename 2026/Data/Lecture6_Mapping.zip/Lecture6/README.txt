Lecture 6: Mapping for Autonomous Driving

Open Labs/Mapping/index.html to play the real KITTI camera/LiDAR sequence offline.
The slide deck is in Presentations/. Recorded display controls do not rerun estimators.
The separate controlled scenario recomputes GPS/loop pose graphs, terrain and failure effects locally.
Visual map scale is arbitrary; LiDAR map units are meters.
KITTI and derived data: CC BY-NC-SA 3.0, Geiger, Lenz, Urtasun, CVPR 2012.
https://www.cvlibs.net/datasets/kitti/
